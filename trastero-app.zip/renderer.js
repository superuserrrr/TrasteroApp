const fs = require('fs');
const path = require('path');

// Directorio de datos dentro del proyecto
const dataDir = path.join(__dirname, 'data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir);
const dataPath = path.join(dataDir, 'items.json');
let items = [];

// Carga inicial desde fichero JSON
function load() {
  try {
    const data = fs.readFileSync(dataPath, 'utf-8');
    items = JSON.parse(data);
  } catch (e) {
    items = [];
  }
  render();
}

// Guarda en fichero JSON
function save() {
  try {
    fs.writeFileSync(dataPath, JSON.stringify(items, null, 2));
  } catch (e) {
    console.error('Error al guardar:', e);
  }
  render();
}

// Renderizado de tabla con filtrado
function render() {
  const filter = document.getElementById('search').value.toLowerCase();
  const tbody = document.querySelector('#itemsTable tbody');
  tbody.innerHTML = '';
  items.forEach((item, index) => {
    if (item.name.toLowerCase().includes(filter) || item.location.toLowerCase().includes(filter)) {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${item.name}</td>
        <td>${item.location}</td>
        <td><button class="delete" onclick="deleteItem(${index})">🗑️</button></td>
      `;
      tbody.appendChild(row);
    }
  });
}

// Elimina un objeto y guarda cambios
window.deleteItem = index => {
  if (confirm('¿Eliminar este objeto?')) {
    items.splice(index, 1);
    save();
  }
};

// Abrir modal para añadir
document.getElementById('addBtn').addEventListener('click', () => {
  document.getElementById('modalTitle').textContent = 'Añadir Objeto';
  document.getElementById('itemName').value = '';
  document.getElementById('itemLocation').value = '';
  document.getElementById('modal').classList.remove('hidden');
});

// Guardar nuevos objetos desde el formulario
document.getElementById('itemForm').addEventListener('submit', e => {
  e.preventDefault();
  const name = document.getElementById('itemName').value.trim();
  const location = document.getElementById('itemLocation').value.trim();
  if (!name || !location) return;
  items.push({ name, location });
  document.getElementById('modal').classList.add('hidden');
  save();
});

// Cancelar y cerrar modal
document.getElementById('cancelBtn').addEventListener('click', () => {
  document.getElementById('modal').classList.add('hidden');
});

// Filtrado en tiempo real
document.getElementById('search').addEventListener('input', render);

// Inicializar carga de datos
load();